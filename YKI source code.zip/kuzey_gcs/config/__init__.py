"""Config package."""
from kuzey_gcs.config.defaults import default_parameters
from kuzey_gcs.config.i18n import t

__all__ = [
    "default_parameters",
    "t",
]
