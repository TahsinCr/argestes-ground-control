from kuzey_gcs.app import run


if __name__ == "__main__":
    raise SystemExit(run())
